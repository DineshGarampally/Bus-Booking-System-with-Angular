export interface IBus{
    "From":String,
    "To":String,
    "TravelDate":String,
    "Seats":Number,
    "AvailableSeats":Number,
    "BusNumber":Number,
    "BusType":String,
    "Arrival":String,
    "Departure":String,
    "Fare":Number,
    "BookedSeats":Array<number>
}