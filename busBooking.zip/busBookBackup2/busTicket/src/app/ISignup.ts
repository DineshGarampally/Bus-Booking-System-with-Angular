export interface ISignup {
    "Name": String,
    "Email": String,
    "MobileNo": Number,
    "Password": String,
    "DOB": String,
    "Gender": String
}