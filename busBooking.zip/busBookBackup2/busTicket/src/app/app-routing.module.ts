import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentGuard } from './guards/payment.guard';
import { SeatsGuard } from './guards/seats.guard';
import { SelectBusGuard } from './guards/select-bus.guard';
import { TicketConfirmGuard } from './guards/ticket-confirm.guard';
import { HomeComponent } from './home/home.component';
import { PaymentComponent } from './home/payment/payment.component';
import { SeatsComponent } from './home/seats/seats.component';
import { SelectingBusComponent } from './home/selecting-bus/selecting-bus.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { TicketComponent } from './home/ticket/ticket.component';

const routes: Routes = [
  {path: "home", component: HomeComponent, children: [
      { path: "selectBus", component: SelectingBusComponent, canActivate: [SelectBusGuard] },
      { path: "seats", component: SeatsComponent, canActivate: [SeatsGuard] },
      { path: "payment", component: PaymentComponent, canActivate: [PaymentGuard] },
      { path: "ticket", component: TicketComponent, canActivate: [TicketConfirmGuard] },
      { path: "",redirectTo:"selectBus",pathMatch:"full"}
    ]
  },
  {path:"signin",component:SigninComponent},
  {path:"signup",component:SignupComponent},
  {path:"",redirectTo:"home",pathMatch:"full"}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
