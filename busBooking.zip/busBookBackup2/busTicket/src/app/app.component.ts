import { Component, OnInit } from '@angular/core';
import { UserDataService } from './user-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  signIn:boolean=false;
  constructor(private _userService:UserDataService){}
  title = 'busTicket';

  ngOnInit(){
    this._userService.signIn.subscribe(data=>{
      this.signIn=data;
    });
  }
}
