import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopNavbarComponent } from './top-navbar/top-navbar.component'
import { SignupComponent } from './signup/signup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SigninComponent } from './signin/signin.component';
import { SelectingBusComponent } from './home/selecting-bus/selecting-bus.component';
import { SeatsComponent } from './home/seats/seats.component';
import { PaymentComponent } from './home/payment/payment.component';
import { HomeComponent } from './home/home.component';
import { TicketComponent } from './home/ticket/ticket.component';
import { SelectBusGuard } from './guards/select-bus.guard';
import { AuthInterceptorService } from './auth-interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    TopNavbarComponent,
    SignupComponent,
    SigninComponent,
    SelectingBusComponent,
    SeatsComponent,
    PaymentComponent,
    HomeComponent,
    TicketComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [SelectBusGuard,
    {
      provide:HTTP_INTERCEPTORS,
      useClass:AuthInterceptorService,
      multi:true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
