import { Injectable } from '@angular/core';
import { HttpHandler, HttpInterceptor, HttpRequest, HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserDataService } from './user-data.service';
@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor{

  constructor(private _userService:UserDataService) { }

  intercept(req:any,next:any){
    var token=this._userService.getToken();
  
    if(token!=null){
    var tokenAddedUrl=req.clone({
      setHeaders:{
        Authorization:token
      }
    })
    return next.handle(tokenAddedUrl)
  }else{
    return next.handle(req);
  }
    
  }
}
