import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { IBus } from './IBus';

@Injectable({
  providedIn: 'root'
})
export class BusDataService {
  
  busDetails:any;
  travellers:any;
  transactionId:number=0;

  constructor(private _http:HttpClient) { }

  busQuery=new Subject();
  // bus query and storing
  sendBusDetails(busInfo:any){
    this.busDetails=busInfo;
  }
  // return bus query
  getBusQuery(){
    if(this.busDetails!=null){
     return this.busDetails
    }else{
      return false;
    }
  }


  getBusRoutes(){
    return this._http.get<IBus>("http://localhost:8081/api/getBusLocations");
  }
  getBusDetails(){
    return this._http.post<IBus>("http://localhost:8081/api/getBus",this.busDetails)
  }
  getBusDetails1(){
    return this._http.post<IBus>("http://localhost:8081/api/getBus",this.busDetails)
  }


  sendPassengerDetails(value:any){
    this.travellers=value;
  }
  resetSeats(){
    this.travellers.Seats=[]
  }
  getPassengerDetails(){
    return this.travellers;
  }
  sendTransaction(transactionNumber:number){
    this.transactionId=transactionNumber;
  }
  getTransactionId(){
    return this.transactionId;
  }
  updateBus(data:any){
    return this._http.put('http://localhost:8081/api/updateSeats',data)
  }
}
