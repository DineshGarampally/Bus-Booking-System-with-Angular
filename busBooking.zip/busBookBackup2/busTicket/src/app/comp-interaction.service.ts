import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompInteractionService {
  
  comp1=true;
  comp2=false;
  comp3=false;
  comp4=false;

  constructor() { }
  comp1Sub=new Subject(); 
  comp2Sub=new Subject(); 
  comp3Sub=new Subject(); 
  comp4Sub=new Subject(); 
  selectBusStatus(){
    return this.comp1;
  }
  selectSeatsStatus(){
    return this.comp2;
  }
  paymentStatus(){
    return this.comp3;
  }
  ticketStatus(){
    return this.comp4;
  }

  // componentStatus(){
  //   {
  //     selectBus:this.comp1
  //     selectSeats:this.comp2
  //     payment:this.comp3
  //     ticket:this.comp4
  //   }
  // }
}
