import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CompInteractionService } from '../comp-interaction.service';
import { UserDataService } from '../user-data.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentGuard implements CanActivate {
  constructor(private _compoInter:CompInteractionService, private _userService:UserDataService ){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this._compoInter.paymentStatus() == true) {
      if (this._userService.checkToken()) {
        this._compoInter.comp2Sub.next(true);
        return true;
      }else{
        return false;
      }
    }else 
    {
      return false;
    }
  }
}
