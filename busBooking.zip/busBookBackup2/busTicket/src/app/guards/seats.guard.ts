import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CompInteractionService } from '../comp-interaction.service';

@Injectable({
  providedIn: 'root'
})
export class SeatsGuard implements CanActivate {
  constructor(private _compoInter:CompInteractionService){}
  canActivate(route: ActivatedRouteSnapshot,state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(this._compoInter.selectSeatsStatus()==true){
      this._compoInter.comp1Sub.next(true);
      return true;
    }else{
      return false
    } 
    
  }

}
