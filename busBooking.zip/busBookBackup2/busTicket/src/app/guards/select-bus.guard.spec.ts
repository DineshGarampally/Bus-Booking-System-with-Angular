import { TestBed } from '@angular/core/testing';

import { SelectBusGuard } from './select-bus.guard';

describe('SelectBusGuard', () => {
  let guard: SelectBusGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(SelectBusGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
