import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CompInteractionService } from '../comp-interaction.service';
import { UserDataService } from '../user-data.service';

@Injectable({
  providedIn: 'root'
})
export class SelectBusGuard implements CanActivate {
  constructor(private _userService:UserDataService,private _router:Router,private _compService:CompInteractionService){}
  canActivate(route: ActivatedRouteSnapshot,state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(this._userService.checkToken()){
      this._userService.signIn.next(true)
      return true;
    }else{
      this._router.navigate(['signin'])
      return false;
    }
  }
  
}