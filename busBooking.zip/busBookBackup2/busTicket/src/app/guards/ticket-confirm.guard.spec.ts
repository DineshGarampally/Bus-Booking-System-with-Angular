import { TestBed } from '@angular/core/testing';

import { TicketConfirmGuard } from './ticket-confirm.guard';

describe('TicketConfirmGuard', () => {
  let guard: TicketConfirmGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(TicketConfirmGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
