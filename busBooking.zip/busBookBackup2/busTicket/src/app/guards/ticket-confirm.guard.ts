import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CompInteractionService } from '../comp-interaction.service';

@Injectable({
  providedIn: 'root'
})
export class TicketConfirmGuard implements CanActivate {
  constructor(private _compoInter:CompInteractionService){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(this._compoInter.ticketStatus()==true){
      this._compoInter.comp3Sub.next(true);
      this._compoInter.comp4Sub.next(true);

      return true;
    }else{ 
      return false;
    }
  }
  
}
