import { Component, OnInit } from '@angular/core';
import { CompInteractionService } from '../comp-interaction.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(private _compService:CompInteractionService){
  }

  
   
  navClick(no:any){
    var activeClass=document.getElementsByClassName('active')[0];
    var allSpans=document.querySelectorAll('span')
    var selectSpanEle=allSpans[no].classList
    for(var i=0;i<allSpans.length;i++){
      
      if(allSpans[i].classList.contains('activated')){
        allSpans[i].classList.add('spanGreen');
      }
      
      if(activeClass){
      selectSpanEle.remove('spanGreen');
      
    }
  }
   
 
  }



  ngOnInit(): void {
    var selectSpanEle=document.querySelectorAll('span');
    var activeClass=document.getElementsByClassName('active')
    this._compService.comp1Sub.subscribe(data=>{
      if(data==true){
        selectSpanEle[0].classList.add("spanGreen","activated")
      }
    })

    this._compService.comp2Sub.subscribe(data=>{
      if(data==true){
        selectSpanEle[1].classList.add("spanGreen","activated")
      }
    })
    this._compService.comp3Sub.subscribe(data=>{
      if(data==true){
        selectSpanEle[2].classList.add("spanGreen","activated")
      }
    })
    this._compService.comp4Sub.subscribe(data=>{
      if(data==true){
        selectSpanEle[3].classList.add('activated')
      }
    })

  }
  

}
