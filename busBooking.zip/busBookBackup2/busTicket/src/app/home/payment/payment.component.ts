import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService } from 'src/app/user-data.service';
import { BusDataService } from '../../bus-data.service';
import { CompInteractionService } from '../../comp-interaction.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
 
  amount:number=0;
  transaction:number=0;
  busNumber:number=0;
  months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  Mastercard=true;
  card="";
  details:any;
  previousBusData:any;
  presentYear=new Date().getFullYear();
  years:any=this.getYears();
  constructor(private _fb:FormBuilder,private _component:CompInteractionService,private _busService:BusDataService,private _userService:UserDataService,private _router:Router) { }
  
  private CardNumberValidators=[
    Validators.required
  ]
  paymentForm=this._fb.group({
    CardType:["",Validators.required],
    CardNumber:["",this.CardNumberValidators],
    CardName:["",[Validators.required,Validators.pattern("[a-zA-Z]*")]],
    CardCvv:["",[Validators.required,Validators.pattern('^[0-9]{3}')]],
    ExpiryDate:this._fb.group({
      expiryMonth:[null,Validators.required],
      expiryYear:[null,Validators.required]
    })
  })

  visaType(event:any){
    this.card=event.target.value;
    if(this.card=="Visa"){
      this.Mastercard=false;
    }else if(this.card=="MasterCard"){
      this.Mastercard=true;
    }
  }
    
  getYears(): any {
    var NoOfYears = [];
    for (var i = 1; i <= 10; i++) {
      NoOfYears.push(this.presentYear++);
    }
    return NoOfYears;
  }
   
  get form(){
    return this.paymentForm.controls;
  }
  
  ngOnInit(): void {
    this.details=this._busService.getPassengerDetails();
    console.log(this.details);
    this.amount=this.details?.Amount;

    // this.busNumber=details?.busNumber;
    this.transaction=Math.floor((Math.random()*100000000)+1);
    this._busService.sendTransaction(this.transaction);
    this.paymentForm.get('CardType')?.valueChanges.subscribe(val=>{
      if(val=="Visa"){
        this.paymentForm.controls['CardNumber'].setValidators(this.CardNumberValidators.concat(Validators.pattern('^[4][0-9]{15}$')))
      }else if(val=="MasterCard"){
        this.paymentForm.controls['CardNumber'].setValidators(this.CardNumberValidators.concat(Validators.pattern('^[5][0-9]{15}$')))
      }
      this.paymentForm.controls['CardNumber'].updateValueAndValidity();
    })
    this._busService.getBusDetails().subscribe(data=>{
      this.previousBusData=data;
      console.log(this.previousBusData)
    },
    err=>{
      if(err instanceof HttpErrorResponse){
        this._userService.signIn.next(false);
      }
    })
  }

  onSubmit(){
   
    this._component.comp4=true;
  
    var finalSeatsAvailable=this.previousBusData.AvailableSeats-this.details.Travellers.length;
    var finalBookedSeats=this.previousBusData.BookedSeats.concat(this.details.Seats)
    var updatedData={
      BusNumber:this.previousBusData.BusNumber,
      AvailableSeats:finalSeatsAvailable,
      BookedSeats:finalBookedSeats
    }
    this._busService.updateBus(updatedData).subscribe(res=>{
      console.log(res);
    })
    this._busService.resetSeats();
    this._router.navigate(['home/ticket']);
  }

}
