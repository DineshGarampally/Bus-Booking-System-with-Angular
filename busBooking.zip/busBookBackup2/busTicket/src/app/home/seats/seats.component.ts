import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService } from 'src/app/user-data.service';
import { BusDataService } from '../../bus-data.service';
import { CompInteractionService } from '../../comp-interaction.service';

@Component({
  selector: 'app-seats',
  templateUrl: './seats.component.html',
  styleUrls: ['./seats.component.css']
})
export class SeatsComponent implements OnInit {
  bookedSeats: any = [];
  seats: any = [];
  finalSeats: any = []
  selectedSeats: any = [];
  busData: any;
  tax: any;
  totalFare:any;
  fare:any;
  
  constructor(private _busService: BusDataService,private _component:CompInteractionService ,private _userService: UserDataService,private _fb: FormBuilder, private _router:Router) { }

  //Creating form array for Name and gender for the selected seats
  bookseatForm = this._fb.group({
    details: this._fb.array([])
  })
  //get method for form array 
  get details() {
    return this.bookseatForm.get('details') as FormArray;
  }
  // creating form group 
  addDetailsGroup(): FormGroup {
    return this._fb.group({
      Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z]{1}[a-zA-Z ]*')]],
      Gender: ['', Validators.required]
    })
  }

  //Clicking on seat
  seatClick(no: number) {
   
      
      
      
    
    console.log(this.bookseatForm.controls['details'])
    var selectedSeat = document.getElementsByClassName('seat' + (no + 1))[0]?.classList;
    var seats = this.selectedSeats;
    // for deleting selected seat in array
    if (selectedSeat.contains("seatSelected")) {
      selectedSeat.remove("seatSelected");
      var count = 0;
      for (var i = 0; i < this.selectedSeats.length; i++) {
        if (seats[i] == null) {
          count++;
        }
        if (this.selectedSeats[i] == (no + 1)) {
          delete this.selectedSeats[i];
          this.details.removeAt(i - count);
          break;
        }
      }
    } else {
      selectedSeat.add("seatSelected");
      this.selectedSeats.push(no + 1);
      (<FormArray>this.bookseatForm.get('details')).push(this.addDetailsGroup());
    }
    this.finalSeats = this.selectedSeats.filter((item: any) => {
      return item != null;
    })
    console.log(this.finalSeats);
    if(this.busData.message != "No details found"){
       this.totalFare=(this.fare*this.finalSeats.length)+(this.finalSeats.length*this.tax);
    }
   
  }
  ngOnInit(): void {

    // this._component.comp1Sub.next(true);
    this._busService.getBusDetails1().subscribe(data => {
      this.busData = data;
      //pushing seat numbers to array
      for (var i = 0; i < 40; i++) {
        this.seats.push(i + 1);
      }
      if (this.busData.message != "No details found") {
        this.fare=this.busData.Fare
        this.tax = (this.fare) * (5 / 100);
        
        console.log(this.tax);
        
        this.bookedSeats = this.busData.BookedSeats;
        console.log(this.bookedSeats);
        console.log(this.busData);

        
        //adding booked in seats array.
        for (var i = 0; i < this.bookedSeats.length; i++) {
          var items = this.bookedSeats[i];
          this.seats[items-1] = "booked"
        }
 
      }

    },
    err=>{
      if(err instanceof HttpErrorResponse){
        this._userService.signIn.next(false);
      }
    }
    )

    
    setTimeout(()=>{
      var previousData=this._busService.getPassengerDetails();
      var PreSelectedSeats=previousData?.Seats;
      var PreFormData=previousData?.Travellers;
      console.log(PreSelectedSeats);
      if(previousData!=null){
        for(var i=0;i<PreSelectedSeats.length;i++){
          this.seatClick(PreSelectedSeats[i] - 1)
        }
        var formArray = <FormArray>this.bookseatForm.controls['details']
        // setTimeout(() => {
          var fc = formArray.controls
          for (var i = 0; i < fc.length; i++) {
            var fg = <FormGroup>formArray.controls[i]
            fg.controls["Name"].setValue(PreFormData[i].Name)
            fg.controls["Gender"].setValue(PreFormData[i].Gender)
          }
        // }, 10)
      }
    }, 100)
   
 

  }
  onSubmit() {
    var travellers:any=[];
    for(var i=0;i<this.finalSeats.length;i++){
      travellers.push({
        Name:this.bookseatForm.value.details[i].Name,
        Gender:this.bookseatForm.value.details[i].Gender,
        SeatNo:this.finalSeats[i]
      })
    }
    var total={
      Seats:this.finalSeats,
      Amount:this.totalFare,
      Travellers:travellers
    }
    this._busService.sendPassengerDetails(total);
    this._component.comp3=true;
    this._router.navigate(['home/payment']);
  }

}




/* notes

removes seats array from total in the lastS

*/