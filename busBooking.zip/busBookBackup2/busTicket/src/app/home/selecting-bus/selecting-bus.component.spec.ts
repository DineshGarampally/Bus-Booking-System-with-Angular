import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectingBusComponent } from './selecting-bus.component';

describe('SelectingBusComponent', () => {
  let component: SelectingBusComponent;
  let fixture: ComponentFixture<SelectingBusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectingBusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectingBusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
