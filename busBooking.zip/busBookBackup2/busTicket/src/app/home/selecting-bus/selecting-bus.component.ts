import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService } from 'src/app/user-data.service';
import { BusDataService } from '../../bus-data.service';
import { CompInteractionService } from '../../comp-interaction.service';

@Component({
  selector: 'app-selecting-bus',
  templateUrl: './selecting-bus.component.html',
  styleUrls: ['./selecting-bus.component.css']
})
export class SelectingBusComponent implements OnInit {
  flag = false;
  noBuses = false;
  sendingBusDetails: any;
  storingBusDetails: any = "";
  fromPlaces: any = [];
  toPlaces: any = [];
  busQuery: any;
  constructor(private _busService: BusDataService, private _component: CompInteractionService, private _userService: UserDataService, private _router: Router) { }

  selectingBus = new FormGroup({
    From: new FormControl(null, [Validators.required]),
    To: new FormControl(null, [Validators.required]),
    TravelDate: new FormControl("", [Validators.required])
  })
  onSubmit() {
    this.storingBusDetails = [];
    this.sendingBusDetails = this.selectingBus.value;

    //sendind selected bus to the service
    this._busService.sendBusDetails(this.sendingBusDetails);

    //getting  the bus found from the service
    this._busService.getBusDetails().subscribe(data => {
      this.storingBusDetails = data;
      if (this.storingBusDetails.message != "No details found") {
        this.flag = true;
        this.noBuses = false;
      } else {
        this.flag = false;
        this.noBuses = true;
      }
    },
      err => {
        if (err instanceof HttpErrorResponse) {
          this._router.navigate(['signin'])
        }
      })
    // disabling the form
    this.selectingBus.disable();
  }

  editForm() {
    this.selectingBus.enable()
  }
  clearForm() {
    this.selectingBus.reset()
  }

  //creating errors if same places are selected
  validatePlaces() {
    var ele1 = document.getElementById("differentPlaces1");
    var ele2 = document.getElementById("differentPlaces2");
    if (this.selectingBus.controls['To'].value == this.selectingBus.controls['From'].value) {
      ele1!.innerHTML = "From and To should be unique";
      ele2!.innerHTML = "From and To should be unique";
    } else {
      ele1!.innerHTML = "";
      ele2!.innerHTML = "";
    }
  }
  // navigate to seat layout component
  viewSeats() {
    this._component.comp2 = true;
    this._router.navigate(['home/seats']);
  }

  ngOnInit(): void {
    var busData: any;
    this._busService.getBusRoutes().subscribe(data => {
      busData = data;
      for (var i = 0; i < busData.length; i++) {
        if (i == 0) {
          this.fromPlaces.push(busData[i].From);
          this.toPlaces.push(busData[i].To);
        } else {
          for (var j = 0; j < this.fromPlaces.length; j++) {
            if ((this.fromPlaces[j]) != (busData[i].From)) {
              this.fromPlaces.push(busData[i].From);
            }
          }
          for (var j = 0; j < this.toPlaces.length; j++) {
            if ((this.toPlaces[j]) != (busData[i].To)) {
              this.toPlaces.push(busData[i].To);
            }
          }
        }
      }
    },
      err => {
        if (err.status == 401) {
          this._userService.signIn.next(false);
          this._router.navigate(['signin'])
        }
      })

    //assigning previous chosen options to elements
    this.busQuery = this._busService.getBusQuery()
    if (this.busQuery != false) {
      this.selectingBus.controls['From'].setValue(this.busQuery.From);
      this.selectingBus.controls['To'].setValue(this.busQuery.To);
      this.selectingBus.controls['TravelDate'].setValue(this.busQuery.TravelDate);
      this.selectingBus.disable();
      this.onSubmit();
    }
  }

}
