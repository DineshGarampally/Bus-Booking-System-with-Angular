import { Component, OnInit } from '@angular/core';
import { BusDataService } from '../../bus-data.service';
import { CompInteractionService } from '../../comp-interaction.service';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css']
})
export class TicketComponent implements OnInit {
  busData:any;
  transactionId:number=0;
  passengerData:any;
  passengers:any;
  seats:any;
  amount:any;
  constructor(private _compInter:CompInteractionService,private _busservice:BusDataService) { }



  print(ele:any){
    // var content=document.getElementsByClassName(ele)[0];
    // var w=window.open("","",'width=1000,height=1000');
    // w?.document.write(content.innerHTML);
    window.print();
  }
  ngOnInit(): void {
    // this._compInter.comp3Sub.next(true);
    this._busservice.getBusDetails1().subscribe(data=>{
      this.busData=data;
      console.log(this.busData);
    })
    
    this.transactionId=this._busservice.getTransactionId();
    this.passengerData=this._busservice.getPassengerDetails();
    this.passengers=this.passengerData.Travellers;
    this.seats=this.passengerData.Seats;
    this.amount=this.passengerData.Amount;
    console.log(this.passengers);
    console.log("seats are: "+this.seats);
    console.log("amount: "+this.amount);
  }

}
