import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService } from '../user-data.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private _fb:FormBuilder, private _userService:UserDataService, private _router:Router) { }
  signinData:any
 

  signinForm=this._fb.group({
    Email:this._fb.control("",[Validators.required, Validators.pattern("^[a-zA-Z]+[#$%_a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]{2,}$")]),
    Password:this._fb.control("",[Validators.required])
  })

  onSubmit() {
    this.signinData = this.signinForm.value;
    console.log(this.signinData);
    this._userService.checkSignin(this.signinData).subscribe(
      data => { 
        console.log(data);
        localStorage.setItem('token',data.token);
        this._userService.signIn.next(true)
        this._router.navigate(['home/selectBus']);
      },
      err=>{
        console.log(err.error.text)
      }
    )
    
  }

  ngOnInit(): void {
  }
}
