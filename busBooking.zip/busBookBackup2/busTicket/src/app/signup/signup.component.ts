import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserDataService } from '../user-data.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  userData:any;
  userExist:boolean=true;
  constructor(private userService:UserDataService) { }

  

  signupForm = new FormGroup({
    Name: new FormControl('', [Validators.required, Validators.pattern("^[A-Za-z]+[a-zA-Z ]*")]),
    Email: new FormControl('', [Validators.required, Validators.email]),
    MobileNo: new FormControl('', [Validators.required, Validators.pattern("^[1-9]{1}[0-9]{9}")]),
    Password: new FormControl('', [Validators.required]),
    DOB: new FormControl('', [Validators.required]),
    Gender:new FormControl('', [Validators.required])
  })

  onSubmit(){
    this.userData=this.signupForm.value;
    console.log(this.userData);
    this.userService.postUserDetails(this.userData).subscribe(
      data=>{console.log(data);},
           
    )
  }

  ngOnInit(): void {
    
  }
}
