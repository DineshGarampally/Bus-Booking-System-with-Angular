import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {
  signIn=new Subject<boolean>();
  constructor(private http:HttpClient) { }
  // To send signup data to Database
  postUserDetails(signupData:any){
    return this.http.post("http://localhost:8081/api/signup",signupData);
  }

  //checking if login data is present in Db or not
  
  checkSignin(signinData:any):Observable<any>{
    return this.http.post("http://localhost:8081/api/signin",signinData);
  }

  checkToken(){
    if(localStorage.getItem('token')!=null){
      return true;
    }else{

      return false;
    }
  }
  getToken(){
    return localStorage.getItem('token');
  }


}
