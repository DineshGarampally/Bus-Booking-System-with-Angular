const BusDetails = require('../../models/busModel');
const jwt = require('jsonwebtoken');
module.exports = function (router) {
    var payload;
    function verifyToken(req, res, next) {

        if (!req.headers.authorization) {
            return res.status(401).send("Unauthorized request")
        }
        let token = req.headers.authorization
        console.log(token)
        if (token === "null") {
            return res.status(401).send("Unauthorized request")
        }
        try {
            payload = jwt.verify(token, "iamcreatinganewKey");
            req.userId = payload.subject;
            next()
        }
        catch (err) {
            return res.status(401).send("Unauthorized request")
        }
    }

    router.get('/getBusLocations', verifyToken, function (req, res) {
        BusDetails.find({}, (err, details) => {
            if (err) {
                res.json(err)
            } else {
                if (!details) {
                    res.json("no busses found")
                } else {
                    res.json(details)
                }
            }
        })
    })

    router.post('/busDetails',verifyToken, function (req, res) {
        let bus = new BusDetails(req.body);
        bus.save(function (err, sign) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(sign)
        })
    })

    // Finding bus based on search details
    router.post('/getBus',verifyToken, function (req, res) {

        BusDetails.findOne({ $and: [{ From: req.body.From }, { To: req.body.To }, { Date: req.body.TravelDate }] }, (err, details) => {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (!details) {
                    res.json({ success: false, message: 'No details found' });
                } else {
                    res.json(details);
                }
            }
        })
    })

    // changing booking seats
    router.put('/updateSeats',verifyToken, (req, res) => {
        console.log(req.body);
        if (!req.body.BusNumber) {
            res.json({ success: false, message: "Bus no is not provided" })
        }
        else {
            BusDetails.findOne({ BusNumber: req.body.BusNumber }, (err, details) => {
                if (err) {
                    res.json({ success: false, message: "Bus No is not valid" });
                } else {
                    details.AvailableSeats = req.body.AvailableSeats;
                    details.BookedSeats = req.body.BookedSeats;
                    details.save((err) => {
                        if (err) {
                            res.json({ success: false, message: err });
                        } else {
                            res.json({ success: true, message: "Booked seats updated" });
                        }
                    })
                }
            })
        }
    })
}