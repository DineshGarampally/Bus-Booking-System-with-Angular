const SignupDetails = require('../../models/signup');
const jwt = require("jsonwebtoken")
module.exports = function (router) {
    
    


    // //get
    // router.get('/details',verifyToken,function(req,res){
    //     SignupDetails.find({},(err,details) =>{
    //         if(err){
    //             res.json({success:false,message:err});
    //         }else{
    //             if(!details){
    //                 res.json({success:false,message:'No details found'});
    //             }else{
    //                 res.json({success:true,Users:details});
    //             }
    //         }
    //     })
    // })


    router.post('/signup', function (req, res) {
        SignupDetails.findOne({ Email: req.body.Email }, (err, user) => {
            if (err) {
                console.log(err);
            } else {
                if (!user) {
                    let sign = new SignupDetails(req.body);
                    sign.save(function (err, sign) {
                        if (err) {
                            return res.status(400).json(err)
                        }
                        res.status(200).json(sign)
                    })
                } else {
                    res.send("already exists");
                }
            }
        })

    })

    router.get('/signupDetails', function (req, res) {
        SignupDetails.find({}, (err, details) => {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (!details) {
                    res.json({ success: false, message: 'No details found' });
                } else {
                    res.json({ success: true, UserInfo: details });
                }
            }
        })
    })

    router.post('/signin', function (req, res) {
        SignupDetails.findOne({Email:req.body.Email},(err,user)=>{
            if(err){
                console.log(err);
            } else {
                if (!user) {
                   res.send("User does not exist")
                }else{
                    if(user.Password!=req.body.Password){
                        res.send("Password is incorrect");
                    }else{
                        var token=jwt.sign({subject:req.body.Email},"iamcreatinganewKey")
                        res.send({token:token})
                    }
                    
                }
            }
        })
    })
}