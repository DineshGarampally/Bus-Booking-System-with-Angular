
const mongoose=require('mongoose');

const busSchema=new mongoose.Schema({
    From:{type:String},
    To:{type:String},
    Date:{type:String},
    Seats:{type:Number},
    AvailableSeats:{type:Number},
    BusNumber:{type:Number},
    BusType:{type:String},
    Arrival:{type:String},
    Departure:{type:String},
    Fare:{type:Number},
    BookedSeats:{type:Array}
})

module.exports=mongoose.model("busDetail",busSchema);