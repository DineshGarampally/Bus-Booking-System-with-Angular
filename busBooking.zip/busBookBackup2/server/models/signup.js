
const mongoose=require('mongoose');

const signupSchema=new mongoose.Schema({
    Name:{type:String},
    Email:{type:String},
    MobileNo:{type:Number},
    Password:{type:String},
    DOB:{type:String},
    Gender:{type:String}
})

module.exports=mongoose.model("signup",signupSchema);